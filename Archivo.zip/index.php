<?php 
header('Location: http://www.ecomasclean.com.mx/public');
exit;
?>