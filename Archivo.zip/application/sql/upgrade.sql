alter table clientes add column tipo_cliente VARCHAR(20) DEFAULT NULL;

DROP TABLE IF EXISTS giros;
CREATE TABLE IF NOT EXISTS giros(
                id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                clave VARCHAR(50),
                descripcion VARCHAR(50)
        )ENGINE=INNODB;

INSERT INTO giros (clave,descripcion)VALUES
("comercializadora","Comercializadora"),
("veterinaria","Veterinaria"),
("educativa","Educativa"),
("gobierno","Gobierno"),
("municipios","Municipios"),
("oficinas","Oficinas"),
("lavaautos","Lava Autos"),
("restaurante","Restaurante"),
("hospital","Hospital"),
("clinica","Clínica"),
("bares","Bares"),
("gymnasio","Gymnasio"),
("iglesia","Iglesia"),
("hogar","Hogar"),
("salon","Salón de Fiestas"),
("servicios","Servicios de Limpieza"),
("hoteleria","Hotelería"),
("lavanderia","Lavandería"),
("miscelanea","Miscelanea"),
("comercio","Comercio en General");

alter table retiros add column tipo varchar(10) default 'M';


